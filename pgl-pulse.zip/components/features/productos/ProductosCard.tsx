import { useState } from "react";

import Button from "@/components/ui/Button";
import Modal from "@/components/ui/Modal";
import Panel from "@/components/ui/Panel";
import Search from "@/components/ui/Search";
import EmptyState from "@/components/ui/EmptyState";

import styles from "./ProductosCard.module.css";

export default function ProductosCard() {

    const [open, setOpen] = useState(false);
    const [search, setSearch] = useState("");

    return (
        <>
            <Panel title="Productos">

                <p className={styles.description}>
                    Gestioná los productos disponibles del sistema.
                </p>

                <Button
                    fullWidth
                    onClick={() => setOpen(true)}
                >
                    Administrar
                </Button>

            </Panel>

            <Modal
                open={open}
                title="Productos"
                description="Administrá el catálogo de productos."
                onClose={() => setOpen(false)}
            >

                <div className={styles.toolbar}>

                    <Search
                        placeholder="Buscar producto..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />

                    <Button>
                        Nuevo
                    </Button>

                </div>

                <EmptyState
                    title="No hay productos"
                    description="Cuando agregues un producto aparecerá aquí."
                />

            </Modal>
        </>
    );

}