import { ReactNode } from "react";

export interface SectionProps {
    title: string;
    description?: string;
    children: ReactNode;
}