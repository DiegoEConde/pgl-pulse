export { default } from "./Panel";
export type { PanelProps } from "./types";