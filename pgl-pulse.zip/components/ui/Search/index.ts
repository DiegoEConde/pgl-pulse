export { default } from "./Search";
export type { SearchProps } from "./types";