import { InputHTMLAttributes } from "react";

export interface InputProps
    extends InputHTMLAttributes<HTMLInputElement> {
    label?: string;
    helperText?: string;
    error?: string;
    fullWidth?: boolean;
    required?: boolean;
}